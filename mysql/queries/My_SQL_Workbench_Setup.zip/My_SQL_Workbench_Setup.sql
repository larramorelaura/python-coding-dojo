SELECT * FROM names;
-- INSERT INTO names(name) VALUES('laura');
-- INSERT INTO names(name) VALUES('jane');
-- INSERT INTO names(name) VALUES('anne'), ('john'), ('jim'), ('katie');

UPDATE names SET name= 'joe' WHERE id=1; 
DELETE FROM names WHERE id=4 OR id=6 OR id=8;