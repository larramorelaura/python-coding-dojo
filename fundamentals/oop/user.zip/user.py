class User:
    def __init__(self, first_name, last_name, email, age):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.age = age
        self.is_rewards_member = False
        self.gold_card_points = 0
    
    def display_info(self, profile):
        print(profile.first_name, profile.last_name, profile.email, profile.age, profile.is_rewards_member, profile.gold_card_points, sep='\n')

    def enroll(self, profile):
        if profile.is_rewards_member !=True:
            profile.is_rewards_member=True
            profile.gold_card_points=200
        else:
            print("Already a rewards member!")
        print(profile.is_rewards_member, profile.gold_card_points)

    def spend_points(self, profile, amount):
        if profile.gold_card_points > amount:
            profile.gold_card_points=profile.gold_card_points-amount
        else:
            print("Not enough points")
        print(profile.gold_card_points)

user_1= User("John", "Smith", "email@noemail.com", 32)
user_1.display_info(user_1)
user_1.enroll(user_1)



user_2 =User("James", "Madison", "email@noemail.com", 54)
user_3 =User("Cheeseburger", "Jones", "email@noemail.com", 65)

user_1.spend_points(user_1, 50)

user_2.enroll(user_2)

user_2.spend_points(user_2, 80)

user_1.display_info(user_1)
user_2.display_info(user_2)
user_3.display_info(user_3)

user_1.enroll(user_1)

user_3.spend_points(user_3, 50)




